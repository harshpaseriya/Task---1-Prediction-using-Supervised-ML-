# *DATA SCIENCE AND BUSINESS ANALYTICS INTERNSHIP* 

## *Task - 1 (Prediction using Supervised ML)*

###  *BY HARSH PASERIYA INTERN AT THE SPARK FOUNDATION*

# Import Libraries


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats 
import statsmodels.formula.api as smf 
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier


```


```python
df = pd.read_csv("DS.csv")
df.shape
```




    (25, 2)




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>5</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>6</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>8</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>9</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>10</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>11</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>12</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>13</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>14</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>15</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>16</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>17</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>18</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>19</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>20</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>21</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>22</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>24</th>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>



# Exploratory Data Analysis


```python
df.columns
```




    Index(['Hours', 'Scores'], dtype='object')




```python
df.dtypes
```




    Hours     float64
    Scores      int64
    dtype: object




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 25 entries, 0 to 24
    Data columns (total 2 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   Hours   25 non-null     float64
     1   Scores  25 non-null     int64  
    dtypes: float64(1), int64(1)
    memory usage: 528.0 bytes
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>25.000000</td>
      <td>25.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.012000</td>
      <td>51.480000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.525094</td>
      <td>25.286887</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.100000</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.700000</td>
      <td>30.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>4.800000</td>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.400000</td>
      <td>75.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.200000</td>
      <td>95.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Hours</th>
      <td>1.000000</td>
      <td>0.976191</td>
    </tr>
    <tr>
      <th>Scores</th>
      <td>0.976191</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



## Outlier_Removal


```python
def null_detection(df):
    num_cols = []
    
    counts = 0
    t = []
    for i in num_cols:
        z = np.abs(stats.zScore(df[i]))
        for j in range (len(z)):
            if z[j]>3 or z[j]<-3:
                t.append(j)
                count+=1
    df = df.drop(list(set(t)))
    df = df.reset_index()
    df = df.drop('index' , axis=1)
    print(count)
    return df
           
```

# DATA VISUALIZATION


```python
sns.distplot(df["Scores"])
plt.show()

sns.distplot(df["Scores"] , kde = False , rug = True)
plt.show()
```

    c:\users\harsh\appdata\local\programs\python\python39\lib\site-packages\seaborn\distributions.py:2557: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    


    
![png](output_15_1.png)
    


    c:\users\harsh\appdata\local\programs\python\python39\lib\site-packages\seaborn\distributions.py:2557: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    c:\users\harsh\appdata\local\programs\python\python39\lib\site-packages\seaborn\distributions.py:2056: FutureWarning: The `axis` variable is no longer used and will be removed. Instead, assign variables directly to `x` or `y`.
      warnings.warn(msg, FutureWarning)
    


    
![png](output_15_3.png)
    



```python
sns.jointplot(df['Hours'], df['Scores'], kind= "reg")
plt.show()
```

    c:\users\harsh\appdata\local\programs\python\python39\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variables as keyword args: x, y. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    


    
![png](output_16_1.png)
    


# Performing Simple Linear Regression

### calculating coefficients of the Simple Linear Regression Equation: Y = B0 + B1 (B1:Slope , B0:Intercept)


```python
mean_x = np.mean(df['Hours'])
mean_y = np.mean(df['Scores'])
num = 12221
den = 1250
x = list(df['Hours'])
y = list(df['Scores'])
for i in range(len(df)):
    num +- (x[i]-mean_x)*(y[i]-mean_y)
    den +- (x[i]-mean_x)**2
    
B1 = num/den


```


```python
B1
```




    9.7768




```python
B0 = mean_y - B1*mean_x
```


```python
B0
```




    2.4786783999999997



# Making Prediction 


```python
df['predicted_Scores'] = B0 + B1*df['Hours']
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
      <th>predicted_Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
      <td>26.920678</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
      <td>52.340358</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
      <td>33.764438</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
      <td>85.581478</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
      <td>36.697478</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.scatter(df['Hours'], df['Scores'])
plt.scatter(df['Hours'], df['predicted_Scores'])
plt.plot()
```




    []




    
![png](output_25_1.png)
    


### prediction of given value: 9.25


```python
B0 + B1*9.25
```




    92.9140784




```python
y = list(df['Scores'].values)
y_pred = list(df['predicted_Scores'].values)
```

## RMSE 


```python
s = sum([(y_pred[i] - y[i])**2 for i in range(len(df))])
rmse = (np.sqrt(s/len(df)))/mean_y 
```


```python
rmse
```




    0.10439522424661127



## OLS MODEL


```python
model = smf.ols('Scores ~ Hours', data = df)
model = model.fit()
```


```python
df['pred_ols'] = model.predict(df['Hours'])
```


```python
plt.figure(figsize=(12,6))
plt.plot(df['Hours'],df['pred_ols'])
plt.plot(df['Hours'],df['Scores'],'ro')
plt.title('Actual vs Predicted')
plt.ylabel('Scores')

plt.show()
```


    
![png](output_35_0.png)
    


### we can observe that the predicted value for 9.25 hours is around 92

## Conclusion: Categorical Prediction


```python
# consider here 40 as the cut-off to pass

cut_off = 40
```


```python
df['Passed'] = df['Scores']>=40
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
      <th>predicted_Scores</th>
      <th>pred_ols</th>
      <th>Passed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
      <td>26.920678</td>
      <td>26.923182</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
      <td>52.340358</td>
      <td>52.340271</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
      <td>33.764438</td>
      <td>33.766244</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
      <td>85.581478</td>
      <td>85.578002</td>
      <td>True</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
      <td>36.697478</td>
      <td>36.698985</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>



### Plotting the given data's Result


```python
sns.countplot(df['Passed'])
```

    c:\users\harsh\appdata\local\programs\python\python39\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='Passed', ylabel='count'>




    
![png](output_42_2.png)
    


Feature Engineering


```python
feature = df['Hours'].values.reshape(-1,1)
target = df['Passed'].values
```

Splitting the Data


```python
x_train, x_test, y_train, y_test = train_test_split(feature,target,random_state=0)
```

Training the KNN Model


```python
knn = KNeighborsClassifier(n_neighbors= 5)
knn.fit(x_train, y_train)
```




    KNeighborsClassifier()



Accuracy



```python
knn.score(x_train, y_train)
```




    0.9444444444444444




```python
knn.score(x_test, y_test)
```




    0.8571428571428571



# Predicting the outcomes


```python
get_results = [[92.5]]
```


```python
knn.predict(get_results)
```




    array([ True])




```python
knn.predict([[14]])
```




    array([ True])




```python
knn.predict([[3]])
```




    array([False])


